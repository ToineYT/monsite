function afficherDerniereChanson() {

    const nomUtilisateur = "Toine_YT";


    const apiKey = "d956af52f2ee966878b57a58e7427dcb";

    
    fetch(`http://ws.audioscrobbler.com/2.0/?method=user.getrecenttracks&user=${nomUtilisateur}&api_key=${apiKey}&format=json`)
      .then(response => response.json())
      .then(data => {
        // Récupération des détails de la dernière chanson
        let derniereChanson = data.recenttracks.track[0];
        // si il n'y a pas de chanson en cours de lecture
        if (derniereChanson["@attr"] && derniereChanson["@attr"].nowplaying) {
          derniereChanson = derniereChanson;
        } else {
          derniereChanson = data.recenttracks.track[1];
        }

        // Affichage des détails de la chanson
        const divChanson = document.getElementById("derniereChanson");
        divChanson.style.opacity = "0";
        setTimeout(() => {
        divChanson.innerHTML = `
          <img class="pic" src="${derniereChanson.image[2]["#text"]}" alt="Pochette d'album"/>
          <p class="title"> ${derniereChanson.name}</p>
          <p class="artiste"> ${derniereChanson.artist["#text"]}</p>
          `;
            divChanson.style.opacity = "1";
        }, 300);
        setTimeout(afficherDerniereChanson, 30 * 1000);
      }).catch((error) => {
          console.log(error);
          setTimeout(afficherDerniereChanson, 30 * 1000);
      });
  }